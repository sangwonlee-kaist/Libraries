#pragma once
#ifndef ISOTHERM_BASE_HPP
#define ISOTHERM_BASE_HPP

#include <functional>

#include "isotherm_base_organ/isotherm_base_def.hpp"
#include "isotherm_base_organ/isotherm_base_impl.hpp"

#endif